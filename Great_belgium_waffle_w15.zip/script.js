/* ============================================================
   GREAT BELGIUM WAFFLE — Menu data + interactivity
   ============================================================ */

// ---------- Small inline icon set (reused across menu items) ----------
const ICONS = {
  waffle:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="M3.5 8.5h17M3.5 14.5h17M8.5 3.5v17M14.5 3.5v17"/></svg>',
  choco:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 10c0-3 2-6 8-6s8 3 8 6-2 4-2 4v4a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-4s-2-1-2-4Z"/><path d="M9 10v3M12 10v3M15 10v3"/></svg>',
  fruit:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="13.5" r="7.5"/><path d="M12 6c0-2 1.5-3.5 3.5-3.5"/></svg>',
  cookie:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8.5"/><circle cx="9" cy="10" r="1" fill="currentColor" stroke="none"/><circle cx="14" cy="9" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="14" r="1" fill="currentColor" stroke="none"/><circle cx="9.5" cy="15" r="1" fill="currentColor" stroke="none"/></svg>',
  velvet:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21c4-3 8-6.5 8-11a5 5 0 0 0-8-4 5 5 0 0 0-8 4c0 4.5 4 8 8 11Z"/></svg>',
  cake:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 12h16v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-6Z"/><path d="M4 12c0-2.5 2-3 2-5M10 12c0-2.5 2-3 2-5M16 12c0-2.5 2-3 2-5"/><path d="M12 3v2"/></svg>',
  addon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 5v14M5 12h14"/></svg>',
  sundae:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 10a5 5 0 0 1 10 0"/><path d="M6 10h12l-2.2 9a2 2 0 0 1-2 1.6h-3.6a2 2 0 0 1-2-1.6L6 10Z"/><path d="M9 3.5s1 1 1 2M12 2.5s1 1.2 1 2.4M15 3.5s1 1 1 2"/></svg>',
  banana:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 6c-1 5 1 13 9 14 4 .4 7-2 7.5-4.5-3 1.5-8 1-9-3"/><path d="M5 6c1.2-.6 2.2-.3 2.6.8"/></svg>',
  spicy:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 10c4-4 12-5 14-2-1 6-8 12-13 10-3-1.2-3.5-5.5-1-8Z"/><path d="M14 4s1.5 1.5 1 3"/></svg>',
  shake:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M8 3h8l-1 4H9L8 3Z"/><path d="M7.5 7h9L15 21H9L7.5 7Z"/><path d="M9.5 11h5"/></svg>',
  mocktail:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 4h14l-7 8v7"/><path d="M9 19h6"/><path d="M8.5 6.5h7"/></svg>',
};

// ---------- Canonical menu data — transcribed from the two supplied menu images ----------
// p is a single visible price; prices is used only where the printed menu has labelled variants.
// badge mirrors the printed mark exactly: star = bestseller, fire = popular, crown = special.
const MENU = [
  { id:'classic', label:'Classic Waffles', icon:'waffle',
    items:[
      {n:'Golden Honey Butter', p:70}, {n:'Maple Bliss Butter', p:80},
      {n:'Cheese Berry Strawberry', p:120, badge:'fire'}, {n:'Blueberry Cream Cheese', p:130, badge:'star'},
      {n:'Butterscotch Crunch', p:130, badge:'star'}, {n:'Belgian Milk Chocolate', p:130, badge:'crown'},
    ]},
  { id:'belgium', label:'Belgium Specials', icon:'choco',
    items:[
      {n:'Almond Royale', p:150, badge:'fire'}, {n:'Walnut Delight', p:150, badge:'star'},
      {n:'Triple Cookie Blast', p:150, badge:'crown'}, {n:'Tiramisu Classic', p:170, badge:'crown'},
      {n:'Molten Volcano', p:190, badge:'fire'}, {n:'Kunafa Chocolate', p:190, badge:'fire'},
    ]},
  { id:'loaded', label:'Loaded Waffles', icon:'choco',
    items:[
      {n:'Belgian Dark Chocolate', p:140, badge:'fire'}, {n:'Dark & White Delight', p:140, badge:'star'},
      {n:'Banana Chocolate', p:140, badge:'crown'}, {n:'Coffee Toffee', p:140, badge:'fire'},
      {n:'Choco Gems Crunch', p:140, badge:'fire'}, {n:'Choco Overload', p:140, badge:'fire'},
      {n:'Triple Chocolate', p:150, badge:'crown'}, {n:'Nutty Nutella', p:150, badge:'crown'},
    ]},
  { id:'fruity', label:'Fruity Tropical', icon:'fruit',
    items:[
      {n:'Tropical Blueberry', p:140, badge:'fire'}, {n:'Tropical Pineapple', p:140, badge:'fire'}, {n:'Tropical Strawberry', p:140, badge:'fire'},
    ]},
  { id:'cookies', label:'Cookies Waffles', icon:'cookie',
    items:[
      {n:'Oreo Crunch', p:130, badge:'star'}, {n:'KitKat Waffle', p:130, badge:'fire'}, {n:'Biscoff Waffle', p:140, badge:'crown'},
    ]},
  { id:'redvelvet', label:'Red Velvet Waffles', icon:'velvet',
    items:[
      {n:'Red Velvet Strawberry Cream Cheese', p:140, badge:'fire'}, {n:'Red Velvet Cotton Candy', p:140, badge:'fire'}, {n:'Red Velvet Cream Cheese', p:140, badge:'crown'},
    ]},
  { id:'cakes', label:'Waffle Cakes', icon:'cake',
    items:[
      {n:'Death by Chocolate', prices:{Single:300,Double:500}, badge:'star'}, {n:'Kookie & Oreo', prices:{Single:300,Double:500}, badge:'star'},
      {n:'Red Velvet Strawberry', prices:{Single:300,Double:500}, badge:'fire'}, {n:'Almond Brownie', prices:{Single:350,Double:520}, badge:'crown'},
      {n:'Walnut Brownie', prices:{Single:350,Double:520}, badge:'crown'}, {n:'Lotus Bicoff', prices:{Single:370,Double:550}, badge:'crown'},
    ]},
  { id:'addon', label:'Add-On', icon:'addon',
    items:[
      {n:'Ice Cream Scoop', priceText:'V-25,C-30'}, {n:'Choco Chips', p:10}, {n:'Banana', p:10}, {n:'Oreo', p:15},
      {n:'KitKat', p:25}, {n:'Almond / Walnut', p:25}, {n:'Lotus Bicoff', p:30}, {n:'Milk, White, Dark Chocolate', priceText:'25,25,30'},
    ]},
  { id:'sundae', label:'Waffle Sundae', icon:'sundae',
    items:[
      {n:'Strawberry Cloud', p:140}, {n:'Choco Brownie', p:140}, {n:'Biscoff Blast', p:140},
    ]},
  { id:'sandwich', label:'Sandwich', icon:'addon', items:[
      {n:'Chocolate (Dark/Milk)', p:100}, {n:'Classic veg', p:110}, {n:'cheese veg', p:130}, {n:'Tomato cheese melt', p:130}, {n:'Tandoori Grilled', p:140}, {n:'Schezwan Veg', p:140}, {n:'Corn cheese', p:140}, {n:'Nutella Banana', p:140}, {n:'Paneer mayo', p:150},
    ]},
  { id:'burger', label:'Burger', icon:'addon', items:[
      {n:'Classic Aloo tiki', p:120}, {n:'Veg classic', p:130}, {n:'cheese Aloo tiki', p:140}, {n:'Tandoori veg', p:150}, {n:'Paneer tikka', p:160},
    ]},
  { id:'banana', label:'Banana Drizzle', icon:'banana',
    items:[
      {n:'Honey Banana Crush', p:60},
      {n:'Milk Choco Banana', p:70},
      {n:'Dark Choco Banana', p:70},
      {n:'Double Choco Banana', p:70},
      {n:'Swiss Nutella Banana', p:90},
    ]},
  { id:'spicy', label:'Spicy Bites', icon:'spicy',
    items:[
      {n:'Peri Peri French Fries', p:70},
      {n:'Veg Fried Momo', p:70}, {n:'Paneer Momo', p:70}, {n:'Mushroom Momo', p:70},
      {n:'Hara Bhara Kabab', p:70},
      {n:'Chilli Garlic Potato', p:70},
      {n:'Sanghai Spring Roll', p:80},
      {n:'Paneer Popcorn', p:80}, {n:'Paneer Fingers', p:100}, {n:'Loaded Fries', p:120},
    ]},
  { id:'frappes', label:'Frappes', icon:'shake', items:[
      {n:'Cold coffee', p:120}, {n:'Hot chocolate', p:130}, {n:'Hazelnut cold coffee', p:140}, {n:'Irish cold coffee', p:140}, {n:'Java chip frappe', p:160},
    ]},
  { id:'shakes', label:'Thick Shakes', icon:'shake',
    items:[
      {n:'Vanilla Shake', p:130}, {n:'Mango Shake', p:130}, {n:'Butterscotch shake', p:130}, {n:'Chocolate Shake', p:140}, {n:'Strawberry Shake', p:140},
      {n:'Oreo Shake', p:150}, {n:'Blueberry Shake', p:160}, {n:'KitKat Shake', p:160}, {n:'Choco Brownie Shake', p:170}, {n:'Biscoff shake', p:180},
    ]},
  { id:'mocktails', label:'Mocktails', icon:'mocktail',
    items:[
      {n:'Virgin Mojito', p:80},
      {n:'Blue Lagoon', p:80},
      {n:'Jamun Masala', p:80},
      {n:'Lime & Mint', p:80},
      {n:'Watermelon', p:80},
      {n:'Spicy Mango', p:80},
      {n:'Chilli Guava', p:80},
    ]},
];

const BADGES = { star:'⭐', fire:'🔥', crown:'👑' };
const SPECIAL_CATEGORY_IDS = new Set(['loaded', 'cookies', 'belgium']);
const SPECIALS_WHITELIST = MENU.filter(category => SPECIAL_CATEGORY_IDS.has(category.id))
  .flatMap(category => category.items.map(item => ({ n:item.n, cat:category.label })));

// A compact fingerprint prevents silent changes to any category, name, price, variant, or badge.
const MENU_AUDIT_HASH = 'a165648';
function hashMenu(value){
  let h = 2166136261;
  for (let i = 0; i < value.length; i++) { h ^= value.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0).toString(16);
}
function auditMenu(){
  const categories = MENU.map(c => c.label);
  const rows = MENU.reduce((sum, c) => sum + c.items.length, 0);
  const snapshot = JSON.stringify(MENU.map(c => [c.id, c.label, c.items.map(i => [i.n, i.p ?? i.priceText ?? i.prices, i.badge ?? ''])]));
  console.assert(MENU.length === 16, `Menu audit failed: expected 16 categories, found ${MENU.length}.`);
  console.assert(rows === 97, `Menu audit failed: expected 97 rows, found ${rows}.`);
  console.assert(new Set(categories).size === 16, 'Menu audit failed: duplicate category.');
  console.assert(hashMenu(snapshot) === MENU_AUDIT_HASH, 'Menu audit failed: a menu name, price, variant, or badge changed.');
  console.assert(SPECIALS_WHITELIST.length === 17 && SPECIALS_WHITELIST.every(entry => SPECIAL_CATEGORY_IDS.has(MENU.find(c => c.label === entry.cat).id)), 'Menu audit failed: daily-special whitelist is invalid.');
}
auditMenu();

// ---------- Menu helpers (everything below reads the one MENU dataset above) ----------
const BADGE_LABELS = { star:'Bestseller', fire:'Popular', crown:'Special' };

// every numeric price an item is sold at (cakes: Single + Double; add-ons: the numbers in the printed price text)
function priceValues(it){
  if (it.prices) return [it.prices.Single, it.prices.Double];
  if (it.priceText) return (it.priceText.match(/\d+/g) || []).map(Number);
  return [it.p];
}
const itemMin = (it) => Math.min(...priceValues(it));
const ALL_PRICES = MENU.flatMap(c => c.items.flatMap(priceValues));
const PRICE_MIN = Math.min(...ALL_PRICES);
const PRICE_MAX = Math.max(...ALL_PRICES);

// Quick filters. They only classify items that already exist in MENU (by name or category); nothing is added.
const WAFFLE_CATS = new Set(['classic','belgium','loaded','fruity','cookies','redvelvet']);
const FOOD_CATS   = new Set([...WAFFLE_CATS, 'cakes', 'sandwich', 'burger', 'spicy']);
const DRINK_CATS  = new Set(['frappes','shakes','mocktails']);
const CHOCO_RE  = /choco|nutella|brownie/i;                 // Choco…, Chocolate…, Nutella, Brownie
const CHOCO_EXTRA = new Set(['Dark & White Delight']);      // dark & white chocolate
const FRUIT_RE  = /strawberr|blueberr|pineapple|mango|banana|watermelon|guava|jamun|lime|berry/i;
const COOKIE_RE = /oreo|kitkat|biscoff|bicoff|cookie|kookie/i;
const QUICK = {
  chocolate:{ label:'Chocolate Lovers', group:'taste', test:(it) => CHOCO_RE.test(it.n) || CHOCO_EXTRA.has(it.n) },
  fruit:    { label:'Fruit Lovers',     group:'taste', test:(it, cat) => cat.id === 'fruity' || FRUIT_RE.test(it.n) },
  cookie:   { label:'Cookie Lovers',    group:'taste', test:(it) => COOKIE_RE.test(it.n) },
  drinks:   { label:'Drinks',           group:'type',  test:(it, cat) => DRINK_CATS.has(cat.id) },
  food:     { label:'Food',             group:'type',  test:(it, cat) => FOOD_CATS.has(cat.id) },
};
const SEARCH_ALIAS = { 'Lotus Bicoff':'biscoff' };           // printed spelling stays; "biscoff" still finds it
const SORT_LABELS = { default:'Default menu order', asc:'Price: Low to High', desc:'Price: High to Low' };

// Price bands generated from the real menu prices (tertiles of every item's starting price, rounded to 5)
const PRICE_BANDS = (() => {
  const starts = MENU.flatMap(c => c.items.map(itemMin)).sort((a, b) => a - b);
  const r5 = (v) => Math.round(v / 5) * 5;
  const e1 = r5(starts[Math.floor(starts.length / 3)]);
  const e2 = r5(starts[Math.floor(starts.length * 2 / 3)]);
  return [ { lo:PRICE_MIN, hi:e1, label:`Up to ${e1}` }, { lo:e1 + 5, hi:e2, label:`${e1 + 5}\u2013${e2}` }, { lo:e2 + 5, hi:PRICE_MAX, label:`${e2 + 5} & above` } ];
})();

const esc = (s) => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function highlightName(name, tokens){
  if (!tokens || !tokens.length) return esc(name);
  const pattern = tokens.slice().sort((x, y) => y.length - x.length).map(t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  return name.split(new RegExp('(' + pattern + ')', 'i')).map((part, i) => i % 2 ? '<mark>' + esc(part) + '</mark>' : esc(part)).join('');
}
const plural = (n) => n === 1 ? 'item' : 'items';

function badgeHtml(it){
  return it.badge ? `<span class="sym" role="img" aria-label="${BADGE_LABELS[it.badge]}" title="${BADGE_LABELS[it.badge]}">${BADGES[it.badge]}</span>` : '';
}

// One menu row: [badge] name · category (in results) · price(s)
function renderItem(it, cat, tokens, showCat){
  const name = `<span class="mi-name">${badgeHtml(it)}<span class="mi-text">${highlightName(it.n, tokens)}</span></span>`;
  const tag = showCat ? `<span class="mi-cat">${esc(cat.label)}</span>` : '';
  let price;
  if (it.prices) price = `<span class="mi-var"><span><i>Single</i><b>${it.prices.Single}</b></span><span><i>Double</i><b>${it.prices.Double}</b></span></span>`;
  else if (it.priceText) price = `<span class="mi-price mi-price--text">${esc(it.priceText)}</span>`;
  else price = `<span class="mi-price">${it.p}</span>`;
  return `<li class="mi"><span class="mi-main">${name}${tag}</span>${price}</li>`;
}

// Waffle cakes: a real table, so Single and Double stay aligned with the right cake
function renderCakeTable(cat, items, tokens, showCat){
  const rows = items.map(it => `
      <tr>
        <th scope="row"><span class="mi-name">${badgeHtml(it)}<span class="mi-text">${highlightName(it.n, tokens)}</span></span>${showCat ? `<span class="mi-cat">${esc(cat.label)}</span>` : ''}</th>
        <td data-label="Single">${it.prices.Single}</td>
        <td data-label="Double">${it.prices.Double}</td>
      </tr>`).join('');
  return `
    <div class="cake-wrap"><table class="cake-table">
      <caption class="sr-only">Waffle Cakes: Single and Double prices</caption>
      <thead><tr><th scope="col">Waffle Cake</th><th scope="col" class="num">Single</th><th scope="col" class="num">Double</th></tr></thead>
      <tbody>${rows}</tbody>
    </table></div>`;
}
function renderCategoryBody(cat, items, tokens, showCat){
  if (cat.id === 'cakes') return renderCakeTable(cat, items, tokens, showCat);
  return `<ul class="mi-grid${cat.id === 'addon' ? ' mi-grid--addon' : ''}">${items.map(it => renderItem(it, cat, tokens, showCat)).join('')}</ul>`;
}
function renderHeading(cat, noteText){
  return `
    <header class="cat-head">
      <div class="cat-title"><span class="cat-ic" aria-hidden="true">${ICONS[cat.icon] || ICONS.waffle}</span><h3>${esc(cat.label)}</h3></div>
      <span class="cat-count">${noteText || `${cat.items.length} ${plural(cat.items.length)}`}</span>
    </header>`;
}

// ---------- Category navigation: looping marquee that is still a real navigation control ----------
const tabsEl = document.getElementById('catTabs');       // the scroller
const panelsEl = document.getElementById('menuPanels');
const SET_COUNT = 3;                                     // three identical copies => seamless wrap in both directions

for (let s = 0; s < SET_COUNT; s++){
  const set = document.createElement('div');
  set.className = 'cat-set';
  if (s !== 1) set.setAttribute('aria-hidden', 'true');    // the middle copy is the one assistive tech sees
  MENU.forEach((cat, i) => {
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.className = 'cat-tab' + (i === 0 ? ' active' : '');
    tab.dataset.cat = cat.id;
    tab.setAttribute('aria-pressed', i === 0 ? 'true' : 'false');
    if (s !== 1) tab.tabIndex = -1;
    tab.innerHTML = `<span class="tab-ic" aria-hidden="true">${ICONS[cat.icon] || ICONS.waffle}</span><span class="tab-label">${esc(cat.label)}</span><span class="tab-count" aria-hidden="true"></span>`;
    set.appendChild(tab);
  });
  tabsEl.appendChild(set);
}
MENU.forEach((cat, i) => {
  const panel = document.createElement('div');
  panel.className = 'menu-panel' + (i === 0 ? ' active' : '');
  panel.id = 'panel-' + cat.id;
  panel.dataset.cat = cat.id;
  panel.innerHTML = renderHeading(cat) + renderCategoryBody(cat, cat.items, null, false);
  panelsEl.appendChild(panel);
});

function setActiveTab(idOrNull){
  tabsEl.querySelectorAll('.cat-tab').forEach(t => {
    const on = idOrNull !== null && t.dataset.cat === idOrNull;
    t.classList.toggle('active', on);
    t.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
}
function activateCategory(id){
  setActiveTab(id);
  panelsEl.querySelectorAll('.menu-panel').forEach(p => p.classList.toggle('active', p.dataset.cat === id));
}
// bring the chosen category's section into view when it isn't already
function revealMenuBody(){
  const target = document.querySelector('.menu-sheet');
  if (!target) return;
  const r = target.getBoundingClientRect();
  if (r.top < 70 || r.top > window.innerHeight * 0.72){
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    window.scrollTo({ top: window.scrollY + r.top - 84, behavior: reduce ? 'auto' : 'smooth' });
  }
}

tabsEl.addEventListener('click', (e) => {
  const btn = e.target.closest('.cat-tab');
  if (!btn) return;
  marquee.nudgePause();
  if (filtersActive()){
    // while filtering, a category narrows the results to it; tapping it again widens back to all
    state.scope = (state.scope === btn.dataset.cat) ? null : btn.dataset.cat;
    renderResults();
    return;
  }
  browseCat = explicitCat = btn.dataset.cat;
  activateCategory(browseCat);
  revealMenuBody();
});

// Marquee engine: time-based drift on scrollLeft (so native touch/trackpad scrolling keeps working), one rAF loop that
// runs only while the strip is on screen, pauses on hover / focus / touch / manual scroll, and never runs for reduced motion.
const marquee = (function(){
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const SPEED = 28;                          // px per second — slow and calm
  let setW = 0, pos = 0, raf = 0, last = 0, visible = false, hovering = false, touching = false, focused = false, holdUntil = 0;
  const sets = () => tabsEl.querySelectorAll('.cat-set');
  function measure(){
    const s = sets();
    if (s.length < 2) return;
    setW = s[1].offsetLeft - s[0].offsetLeft;
    if (setW > 0 && (tabsEl.scrollLeft < setW * 0.5 || tabsEl.scrollLeft >= setW * 2.5)) tabsEl.scrollLeft = setW + (tabsEl.scrollLeft % setW);
    pos = tabsEl.scrollLeft;
  }
  function wrap(){
    if (!setW) return;
    const x = tabsEl.scrollLeft;
    if (x >= setW * 2){ tabsEl.scrollLeft = x - setW; pos = tabsEl.scrollLeft; }
    else if (x < setW){ tabsEl.scrollLeft = x + setW; pos = tabsEl.scrollLeft; }
  }
  function step(t){
    raf = 0;
    if (!visible) { last = 0; return; }
    const dt = last ? Math.min(64, t - last) : 16; last = t;
    if (!touching) wrap();
    const paused = reduce || hovering || touching || focused || t < holdUntil;
    if (!paused && setW){
      if (Math.abs(tabsEl.scrollLeft - pos) > 2) pos = tabsEl.scrollLeft;      // user moved it: follow
      pos += SPEED * dt / 1000;
      tabsEl.scrollLeft = pos;
    } else { pos = tabsEl.scrollLeft; }
    raf = requestAnimationFrame(step);
  }
  const kick = () => { if (!raf && visible) raf = requestAnimationFrame(step); };
  const hold = (ms) => { holdUntil = performance.now() + ms; };
  tabsEl.addEventListener('mouseenter', () => { hovering = true; });
  tabsEl.addEventListener('mouseleave', () => { hovering = false; pos = tabsEl.scrollLeft; });
  tabsEl.addEventListener('touchstart', () => { touching = true; }, { passive:true });
  const endTouch = () => { touching = false; hold(2500); };
  tabsEl.addEventListener('touchend', endTouch, { passive:true });
  tabsEl.addEventListener('touchcancel', endTouch, { passive:true });
  tabsEl.addEventListener('wheel', () => hold(2500), { passive:true });
  tabsEl.addEventListener('focusin', () => { focused = true; });
  tabsEl.addEventListener('focusout', () => { focused = false; hold(1500); });
  tabsEl.addEventListener('scroll', () => { if (!touching) wrap(); }, { passive:true });
  if ('IntersectionObserver' in window){
    new IntersectionObserver(es => { visible = es[0].isIntersecting; if (visible){ measure(); kick(); } }, { threshold:0.05 }).observe(tabsEl);
  } else { visible = true; }
  window.addEventListener('resize', () => { measure(); }, { passive:true });
  window.addEventListener('load', () => { measure(); kick(); });
  requestAnimationFrame(() => { measure(); });
  return { nudgePause: () => hold(3000), measure };
})();

// ---------- Search + filters + sort (one state object, one render path) ----------
const searchInput = document.getElementById('menuSearch');
const searchWrap = searchInput.closest('.menu-search');
const searchClearBtn = document.getElementById('menuSearchClear');
const searchStatus = document.getElementById('menuSearchStatus');
const resultsEl = document.getElementById('menuResults');
const noResults = document.getElementById('menuNoResults');
const noResultsText = document.getElementById('menuNoResultsText');
const clearAllBtns = document.querySelectorAll('[data-clear-all]');
const menuCount = document.getElementById('menuCount');
const menuSection = document.getElementById('menu');
const rangeMin = document.getElementById('priceMin');
const rangeMax = document.getElementById('priceMax');
const priceOut = document.getElementById('priceOut');
const priceFill = document.getElementById('priceFill');
const bandsEl = document.getElementById('priceBands');
const sortSel = document.getElementById('menuSort');
const activeEl = document.getElementById('mfActive');
const filterToggle = document.getElementById('mfToggle');
const filterPanel = document.getElementById('mfPanel');
rangeMin.min = rangeMax.min = PRICE_MIN; rangeMin.max = rangeMax.max = PRICE_MAX; rangeMin.value = PRICE_MIN; rangeMax.value = PRICE_MAX;
const totalItems = MENU.reduce((s, c) => s + c.items.length, 0);
if (menuCount) menuCount.textContent = `${totalItems} menu rows across ${MENU.length} categories`;

const state = { q:'', min:PRICE_MIN, max:PRICE_MAX, sort:'default', tastes:new Set(), type:null, scope:null };
let browseCat = MENU[0].id;      // category shown when browsing without filters
let explicitCat = null;          // category the visitor picked on purpose (carried into filtered views)

function normalizeText(s){
  return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
}
const SEARCH_INDEX = MENU.map((cat, ci) => ({
  cat, ci,
  entries: cat.items.map((it, idx) => {
    const key = normalizeText(`${it.n} ${SEARCH_ALIAS[it.n] || ''}`);          // item names only (plus the one hidden alias)
    return { it, idx, key, words: key.split(' '), min:itemMin(it), prices:priceValues(it) };
  })
}));

const priceFiltered = () => state.min > PRICE_MIN || state.max < PRICE_MAX;
function filtersActive(){
  return state.q.trim() !== '' || priceFiltered() || state.sort !== 'default' || state.tastes.size > 0 || state.type !== null;
}
function textScore(e, tokens){
  let s = 0;
  for (const t of tokens){
    if (!e.key.includes(t)) return -1;
    s += e.words.some(w => w.startsWith(t)) ? 2 : 1;
  }
  return s;
}
// All filters AND together; the taste chips (chocolate / fruit / cookie) are OR'd with each other.
function compute(){
  // "chocolate" also finds the menu's "Choco" spelling (Choco Brownie, Choco Overload …)
  const tokens = normalizeText(state.q).split(' ').filter(Boolean).map(t => t === 'chocolate' ? 'choco' : t);
  const tasteTests = [...state.tastes].map(k => QUICK[k].test);
  const typeTest = state.type ? QUICK[state.type].test : null;
  const perCat = new Map();
  const flat = [];
  for (const { cat, ci, entries } of SEARCH_INDEX){
    for (const e of entries){
      const s = tokens.length ? textScore(e, tokens) : 0;
      if (s < 0) continue;
      if (typeTest && !typeTest(e.it, cat)) continue;
      if (tasteTests.length && !tasteTests.some(f => f(e.it, cat))) continue;
      if (priceFiltered() && !e.prices.some(p => p >= state.min && p <= state.max)) continue;
      flat.push({ it:e.it, cat, ci, idx:e.idx, s, min:e.min });
      perCat.set(cat.id, (perCat.get(cat.id) || 0) + 1);
    }
  }
  return { tokens, flat, perCat };
}

function setVisibleMode(on){
  menuSection.classList.toggle('search-active', on);
  panelsEl.hidden = on;
  resultsEl.hidden = !on;
  if (!on){ resultsEl.innerHTML = ''; noResults.classList.remove('show'); }
}

function renderResults(){
  const hasText = searchInput.value.length > 0;
  searchClearBtn.hidden = !hasText;
  searchWrap.classList.toggle('has-text', hasText);
  syncControls();
  renderActive();

  if (!filtersActive()){
    state.scope = null;
    setVisibleMode(false);
    tabsEl.querySelectorAll('.cat-tab').forEach(t => { t.classList.remove('no-match'); t.querySelector('.tab-count').textContent = ''; });
    activateCategory(browseCat);
    searchStatus.textContent = '';
    return;
  }
  setVisibleMode(true);
  const { tokens, flat, perCat } = compute();
  tabsEl.querySelectorAll('.cat-tab').forEach(t => {
    const n = perCat.get(t.dataset.cat) || 0;
    t.querySelector('.tab-count').textContent = n;
    t.classList.toggle('no-match', n === 0);
  });
  setActiveTab(state.scope);

  const rows = state.scope ? flat.filter(r => r.cat.id === state.scope) : flat;
  const scopeLabel = state.scope ? MENU.find(c => c.id === state.scope).label : '';
  searchStatus.textContent = rows.length
    ? `${rows.length} ${plural(rows.length)} found`
    : 'No matching items found';

  if (!rows.length){
    resultsEl.innerHTML = '';
    noResults.classList.add('show');
    noResultsText.textContent = scopeLabel && flat.length ? `No matching items found in ${scopeLabel}.` : 'No matching items found.';
    return;
  }
  noResults.classList.remove('show');

  if (state.sort === 'default'){
    // grouped by category, in menu order; best text matches first within a category
    const groups = new Map();
    rows.forEach(r => { if (!groups.has(r.cat.id)) groups.set(r.cat.id, { cat:r.cat, rows:[] }); groups.get(r.cat.id).rows.push(r); });
    resultsEl.innerHTML = [...groups.values()].map(g => {
      g.rows.sort((a, b) => b.s - a.s || a.idx - b.idx);
      return `<section class="menu-panel menu-result-group active" aria-label="${esc(g.cat.label)}">
        ${renderHeading(g.cat, `${g.rows.length} ${plural(g.rows.length)}`)}
        ${renderCategoryBody(g.cat, g.rows.map(r => r.it), tokens, true)}
      </section>`;
    }).join('');
  } else {
    // one flat list across the chosen scope, ordered by each item's (starting) price
    const dir = state.sort === 'asc' ? 1 : -1;
    const sorted = rows.slice().sort((a, b) => (a.min - b.min) * dir || a.ci - b.ci || a.idx - b.idx);
    resultsEl.innerHTML = `<section class="menu-panel menu-result-group active" aria-label="${esc(SORT_LABELS[state.sort])}">
      <header class="cat-head"><div class="cat-title"><span class="cat-ic" aria-hidden="true">${ICONS.addon}</span><h3>${esc(SORT_LABELS[state.sort])}</h3></div><span class="cat-count">${sorted.length} ${plural(sorted.length)}</span></header>
      <ul class="mi-grid">${sorted.map(r => renderItem(r.it, r.cat, tokens, true)).join('')}</ul>
    </section>`;
  }
}

// ----- controls <-> state -----
function syncControls(){
  rangeMin.value = state.min; rangeMax.value = state.max;
  const span = PRICE_MAX - PRICE_MIN;
  priceFill.style.setProperty('--lo', ((state.min - PRICE_MIN) / span * 100) + '%');
  priceFill.style.setProperty('--hi', ((state.max - PRICE_MIN) / span * 100) + '%');
  priceOut.textContent = priceFiltered() ? `${state.min} \u2013 ${state.max}` : 'Any price';
  priceOut.classList.toggle('on', priceFiltered());
  sortSel.value = state.sort;
  rangeMin.style.zIndex = state.min > (PRICE_MIN + PRICE_MAX) / 2 ? 3 : 2;   // keep the lower thumb reachable at the far end
  document.querySelectorAll('.mf-chip[data-q]').forEach(b => {
    const k = b.dataset.q, on = QUICK[k].group === 'taste' ? state.tastes.has(k) : state.type === k;
    b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
  bandsEl.querySelectorAll('.band').forEach(b => {
    const on = +b.dataset.lo === state.min && +b.dataset.hi === state.max;
    b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
}

function renderActive(){
  const chips = [];
  const add = (label, kind) => chips.push(`<button type="button" class="af" data-remove="${kind}" aria-label="Remove filter: ${esc(label)}"><span>${esc(label)}</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M7 7l10 10M17 7L7 17"/></svg></button>`);
  if (state.q.trim()) add(`\u201C${state.q.trim()}\u201D`, 'q');
  if (state.scope) add(MENU.find(c => c.id === state.scope).label, 'scope');
  state.tastes.forEach(k => add(QUICK[k].label, 'taste:' + k));
  if (state.type) add(QUICK[state.type].label, 'type');
  if (priceFiltered()) add(`Price ${state.min}\u2013${state.max}`, 'price');
  if (state.sort !== 'default') add(SORT_LABELS[state.sort], 'sort');
  activeEl.hidden = chips.length === 0;
  activeEl.innerHTML = chips.length ? `<span class="af-label">Active</span>${chips.join('')}<button type="button" class="af-clear" data-clear-all>Clear all filters</button>` : '';
}

function clearAll({ focus = false } = {}){
  state.q = ''; state.min = PRICE_MIN; state.max = PRICE_MAX; state.sort = 'default'; state.tastes.clear(); state.type = null; state.scope = null;
  explicitCat = null;
  searchInput.value = '';
  renderResults();
  if (focus) searchInput.focus();
}

// choosing a sort order after picking a category sorts that category (shown as a removable chip); search, quick filters and price always span the whole menu
function enterFilterScope(){ if (!filtersActive() && explicitCat) state.scope = explicitCat; }

let rf = 0;
const schedule = () => { if (!rf) rf = requestAnimationFrame(() => { rf = 0; renderResults(); }); };

searchInput.addEventListener('input', () => { state.q = searchInput.value; schedule(); });
searchClearBtn.addEventListener('click', () => { state.q = ''; searchInput.value = ''; renderResults(); searchInput.focus(); });
searchInput.addEventListener('keydown', (e) => {
  if (e.key === 'Escape'){ e.preventDefault(); if (searchInput.value){ state.q = ''; searchInput.value = ''; renderResults(); } else searchInput.blur(); }
  else if (e.key === 'Enter'){ e.preventDefault(); if (window.matchMedia('(pointer: coarse)').matches) searchInput.blur(); }
});

document.querySelectorAll('.mf-chip[data-q]').forEach(b => b.addEventListener('click', () => {
  const k = b.dataset.q;
  if (QUICK[k].group === 'taste'){ state.tastes.has(k) ? state.tastes.delete(k) : state.tastes.add(k); }
  else { state.type = state.type === k ? null : k; }       // Drinks / Food are mutually exclusive
  renderResults();
}));

function onRange(which){
  let lo = +rangeMin.value, hi = +rangeMax.value;
  if (lo > hi){ if (which === 'min') lo = hi; else hi = lo; }
  state.min = lo; state.max = hi;
  schedule();
}
rangeMin.addEventListener('input', () => onRange('min'));
rangeMax.addEventListener('input', () => onRange('max'));

bandsEl.innerHTML = PRICE_BANDS.map(b => `<button type="button" class="band" data-lo="${b.lo}" data-hi="${b.hi}" aria-pressed="false">${esc(b.label)}</button>`).join('');
bandsEl.addEventListener('click', (e) => {
  const b = e.target.closest('.band'); if (!b) return;
  const same = +b.dataset.lo === state.min && +b.dataset.hi === state.max;
  state.min = same ? PRICE_MIN : +b.dataset.lo; state.max = same ? PRICE_MAX : +b.dataset.hi;
  renderResults();
});

sortSel.addEventListener('change', () => { enterFilterScope(); state.sort = sortSel.value; renderResults(); });

document.getElementById('menu').addEventListener('click', (e) => {
  if (e.target.closest('[data-clear-all]')){ clearAll(); return; }
  const rm = e.target.closest('[data-remove]');
  if (!rm) return;
  const k = rm.dataset.remove;
  if (k === 'q'){ state.q = ''; searchInput.value = ''; }
  else if (k === 'scope'){ state.scope = null; explicitCat = null; }
  else if (k === 'type') state.type = null;
  else if (k === 'price'){ state.min = PRICE_MIN; state.max = PRICE_MAX; }
  else if (k === 'sort') state.sort = 'default';
  else if (k.startsWith('taste:')) state.tastes.delete(k.slice(6));
  renderResults();
});

// mobile: price + sort live in a collapsible row (always open on larger screens via CSS)
filterToggle.addEventListener('click', () => {
  const open = filterPanel.classList.toggle('open');
  filterToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
});

// "/" focuses the search from anywhere (desktop shortcut), unless the user is already typing somewhere
document.addEventListener('keydown', (e) => {
  if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
  const t = e.target;
  if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
  if (typeof fullMenuModal !== 'undefined' && !fullMenuModal.hidden) return;
  e.preventDefault();
  searchInput.focus();
});

syncControls();

// ---------- View All Menu modal ----------
const viewAllBtn = document.getElementById('viewAllMenuBtn');
const fullMenuModal = document.getElementById('fullMenuModal');
const fullMenuBody = document.getElementById('fullMenuBody');
const fullMenuClose = document.getElementById('fullMenuClose');
const fullMenuBackdrop = document.getElementById('fullMenuBackdrop');
let fullMenuBuilt = false;
let lastFocusedEl = null;

function buildFullMenu(){
  if (fullMenuBuilt) return;
  fullMenuBody.innerHTML = MENU.map(cat => `
    <div class="full-menu-cat menu-panel active">
      ${renderHeading(cat)}
      ${renderCategoryBody(cat, cat.items, null, false)}
    </div>`).join('');
  fullMenuBuilt = true;
}
function openFullMenu(){
  buildFullMenu();
  lastFocusedEl = document.activeElement;
  fullMenuModal.hidden = false;
  requestAnimationFrame(() => fullMenuModal.classList.add('open'));
  document.body.classList.add('nav-open');
  fullMenuClose.focus();
}
function closeFullMenu(){
  fullMenuModal.classList.remove('open');
  document.body.classList.remove('nav-open');
  setTimeout(() => { fullMenuModal.hidden = true; }, 260);
  if (lastFocusedEl) lastFocusedEl.focus();
}
if (viewAllBtn){
  viewAllBtn.addEventListener('click', openFullMenu);
  fullMenuClose.addEventListener('click', closeFullMenu);
  fullMenuBackdrop.addEventListener('click', closeFullMenu);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !fullMenuModal.hidden) closeFullMenu();
  });
}


// ---------- Waffle marquee: pause on hover / touch, resume after ----------
(function marquee(){
  const strip = document.querySelector('.marquee-strip');
  const track = document.getElementById('marqueeTrack');
  if (!strip || !track) return;
  let resumeTimer = null;
  function pause(){ track.style.animationPlayState = 'paused'; }
  function resume(){ track.style.animationPlayState = 'running'; }
  strip.addEventListener('mouseenter', pause);
  strip.addEventListener('mouseleave', resume);
  strip.addEventListener('touchstart', () => {
    pause();
    clearTimeout(resumeTimer);
  }, { passive:true });
  strip.addEventListener('touchend', () => {
    clearTimeout(resumeTimer);
    resumeTimer = setTimeout(resume, 1000);
  }, { passive:true });
})();

// ---------- Hero image slot: if a real photo is dropped in later, hide the vector fallback automatically ----------
(function heroImageSlot(){
  const slot = document.getElementById('heroImageSlot');
  if (!slot) return;
  const photo = slot.querySelector('.hero-photo');
  if (photo){
    slot.classList.add('has-photo');
  }
})();

// ---------- Mobile nav ----------
const mobileNav = document.getElementById('mobileNav');
const navToggle = document.getElementById('navToggle');
const navClose = document.getElementById('navClose');
function openNav(){ mobileNav.classList.add('open'); document.body.classList.add('nav-open'); navToggle.setAttribute('aria-expanded','true'); }
function closeNav(){ mobileNav.classList.remove('open'); document.body.classList.remove('nav-open'); navToggle.setAttribute('aria-expanded','false'); }
navToggle.addEventListener('click', openNav);
navClose.addEventListener('click', closeNav);
mobileNav.querySelectorAll('a').forEach(a => a.addEventListener('click', closeNav));
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && mobileNav.classList.contains('open')){ closeNav(); navToggle.focus(); } });
window.matchMedia('(min-width:1100px)').addEventListener('change', (e) => { if (e.matches) closeNav(); });

// ---------- Sticky navbar state + active link (no layout reads on scroll) ----------
const navbar = document.getElementById('navbar');
const sections = document.querySelectorAll('main section[id]');
const navLinks = document.querySelectorAll('.nav-links a, .mobile-nav-links a');
let navScrolled = null, navTicking = false;
function onScroll(){
  navTicking = false;
  const on = window.scrollY > 40;
  if (on !== navScrolled){ navScrolled = on; navbar.classList.toggle('scrolled', on); }
}
window.addEventListener('scroll', () => { if (!navTicking){ navTicking = true; requestAnimationFrame(onScroll); } }, { passive:true });
onScroll();
function setActiveLink(id){
  navLinks.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + id));
}
if ('IntersectionObserver' in window){
  const activeIO = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) setActiveLink(e.target.id); });
  }, { rootMargin:'-30% 0px -60% 0px' });
  sections.forEach(sec => activeIO.observe(sec));
}

// ---------- FAQ accordion ----------
document.querySelectorAll('.faq-item').forEach(item => {
  const btn = item.querySelector('.faq-q');
  const panel = item.querySelector('.faq-a');
  btn.addEventListener('click', () => {
    const isOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item.open').forEach(other => {
      if (other !== item){
        other.classList.remove('open');
        other.querySelector('.faq-a').style.maxHeight = null;
        other.querySelector('.faq-q').setAttribute('aria-expanded','false');
      }
    });
    if (isOpen){
      item.classList.remove('open');
      panel.style.maxHeight = null;
      btn.setAttribute('aria-expanded','false');
    } else {
      item.classList.add('open');
      panel.style.maxHeight = panel.scrollHeight + 'px';
      btn.setAttribute('aria-expanded','true');
    }
  });
});

// ---------- Scroll reveal ----------
const revealEls = document.querySelectorAll('.reveal, .edge');
if ('IntersectionObserver' in window){
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        entry.target.classList.add('in-view');
        io.unobserve(entry.target);
      }
    });
  }, { threshold:0.12, rootMargin:'0px 0px -40px 0px' });
  revealEls.forEach(el => io.observe(el));
} else {
  revealEls.forEach(el => el.classList.add('in-view'));
}


// ---------- Pause looping animations while their section is off-screen ----------
(function pauseOffscreen(){
  if (!('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver(es => es.forEach(e => e.target.classList.toggle('is-paused', !e.isIntersecting)), { rootMargin:'60px 0px' });
  document.querySelectorAll('.hero, .marquee-strip, .story, .insta, .final-cta').forEach(el => io.observe(el));
})();

// ---------- Gentle parallax: desktop/fine pointers only, one rAF, writes only the independent `translate` property ----------
(function parallax(){
  const canHover = window.matchMedia && matchMedia('(hover: hover) and (pointer: fine)').matches;
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!canHover || reduce) return;
  const hero = document.querySelector('.hero');
  const gold = hero && hero.querySelector('.hero-slab--gold');
  const choc = hero && hero.querySelector('.hero-slab--choco');
  const slot = hero && hero.querySelector('.hero-image-slot');
  const items = Array.from(document.querySelectorAll('[data-parallax]'));
  const visible = new Set();
  let ticking = false, heroVisible = true;
  if ('IntersectionObserver' in window){
    const vio = new IntersectionObserver(es => es.forEach(e => {
      if (e.target === hero) heroVisible = e.isIntersecting;
      else if (e.isIntersecting) visible.add(e.target); else visible.delete(e.target);
    }), { rootMargin:'120px 0px' });
    items.forEach(i => vio.observe(i));
    if (hero) vio.observe(hero);
  } else { items.forEach(i => visible.add(i)); }
  function update(){
    ticking = false;
    const vh = window.innerHeight;
    if (heroVisible && hero){
      const r = hero.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, -r.top / r.height));
      if (gold) gold.style.translate = '0 ' + (-26 * p).toFixed(1) + 'px';
      if (choc) choc.style.translate = '0 ' + (14 * p).toFixed(1) + 'px';
      if (slot) slot.style.translate = '0 ' + (-10 * p).toFixed(1) + 'px';
    }
    visible.forEach(el => {
      const r = (el.parentElement || el).getBoundingClientRect();
      const d = r.top + r.height / 2 - vh / 2;
      el.style.translate = '0 ' + Math.max(-36, Math.min(36, d * parseFloat(el.dataset.parallax))).toFixed(1) + 'px';
    });
  }
  window.addEventListener('scroll', () => { if (!ticking){ ticking = true; requestAnimationFrame(update); } }, { passive:true });
  window.addEventListener('resize', update, { passive:true });
  update();
})();

// ---------- Hero load animation ----------
window.addEventListener('DOMContentLoaded', () => {
  const hero = document.querySelector('.hero');
  requestAnimationFrame(() => {
    setTimeout(() => hero.classList.add('is-ready'), 60);
  });
});

// ---------- Current year ----------
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// ---------- Today's Special toast (one per calendar day, deterministic) ----------
(function todaysSpecial(){
try {
  const STORAGE_KEY = 'gbw_daily_special_v1';

  // The café's calendar, not the visitor's device timezone, selects the daily special.
  function localDateKey(d){
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone:'Asia/Kolkata', year:'numeric', month:'2-digit', day:'2-digit' }).formatToParts(d || new Date());
    const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  }

  // Deterministic 32-bit string hash (djb2) — same date string always yields the same index,
  // in any tab, browser, or device, with no shared server required.
  function hashString(str){
    let h = 5381;
    for (let i = 0; i < str.length; i++){
      h = ((h << 5) + h) + str.charCodeAt(i);
      h = h & h;
    }
    return Math.abs(h);
  }

  function pickForDate(dateKey){
    const idx = hashString(dateKey) % SPECIALS_WHITELIST.length;
    return SPECIALS_WHITELIST[idx];
  }

  // Confirm each derived whitelist entry still belongs to the canonical menu.
  function menuPriceFor(entry){
    const cat = MENU.find(c => c.label === entry.cat);
    const item = cat && cat.items.find(i => i.n === entry.n);
    return item && typeof item.p === 'number' ? item.p : null;
  }

  function isValidEntry(entry){
    if (!entry || typeof entry.n !== 'string' || typeof entry.cat !== 'string') return false;
    return SPECIALS_WHITELIST.some(w => w.n === entry.n && w.cat === entry.cat) && menuPriceFor(entry) !== null;
  }

  let memoryFallback = null; // used only if localStorage is unavailable (private browsing, in-app browsers, blocked storage, etc.)

  function readState(){
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : memoryFallback;
    } catch(e){
      return memoryFallback;
    }
  }

  function writeState(state){
    memoryFallback = state;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch(e){ /* storage unavailable — memory fallback still keeps this tab consistent */ }
  }

  // Get (creating if needed) today's state, re-checked against the CURRENT date every time it's called —
  // not just once at load — so a tab that was asleep/backgrounded across midnight still lands on today's item.
  function getTodayState(){
    const todayKey = localDateKey();
    let state = readState();
    if (!state || state.date !== todayKey || !isValidEntry(state.item)){
      state = { date: todayKey, item: pickForDate(todayKey), shown: false };
      writeState(state);
    }
    return state;
  }

  const toast = document.getElementById('specialToast');
  const nameEl = document.getElementById('specialToastName');
  const closeBtn = document.getElementById('specialToastClose');
  if (!toast || !nameEl || !closeBtn) return;   // markup missing — nothing safe to do

  let revealed = false;     // guards against any possibility of a duplicate reveal in this tab
  let scheduleTimer = null;
  let autoCloseTimer = null;
  let retryTimer = null;

  function blockingOverlayOpen(){
    // The mobile menu and the "View All Menu" modal both flag themselves this way — showing the
    // toast underneath either would make it invisible (and, with auto-close, let it expire unseen).
    const fm = document.getElementById('fullMenuModal');
    return document.body.classList.contains('nav-open') || !!(fm && !fm.hidden);
  }

  function closeToast(){
    if (toast.hidden) return;
    clearTimeout(autoCloseTimer);
    toast.classList.remove('is-visible');
    toast.classList.add('is-leaving');
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    setTimeout(() => {
      toast.hidden = true;
      toast.classList.remove('is-leaving');
    }, reduce ? 260 : 340);
  }
  // Keep the toast up while the visitor is reading/pointing at it; restart a short countdown afterwards.
  toast.addEventListener('mouseenter', () => clearTimeout(autoCloseTimer));
  toast.addEventListener('mouseleave', () => { if (toast.classList.contains('is-visible')){ clearTimeout(autoCloseTimer); autoCloseTimer = setTimeout(closeToast, 3000); } });
  closeBtn.addEventListener('click', () => {
    clearTimeout(scheduleTimer);
    clearTimeout(retryTimer);
    closeToast();
  });

  // Paint the toast in. Uses rAF (needed so the browser registers the "hidden" removal as a distinct
  // frame before the transition-triggering class is added — required by some WebKit versions), guarded
  // by a plain setTimeout fallback in case rAF itself doesn't fire promptly for any reason.
  function paintIn(){
    toast.hidden = false;
    let done = false;
    const apply = () => {
      if (done) return;
      done = true;
      toast.classList.add('is-visible');
      const autoCloseDelay = 7000 + Math.floor(Math.random() * 3000); // 7–10s on screen
      autoCloseTimer = setTimeout(closeToast, autoCloseDelay);
    };
    requestAnimationFrame(() => requestAnimationFrame(apply));
    setTimeout(apply, 400); // safety net: fires only if both rAFs above never ran
  }

  // Only actually reveal once the tab is visible AND no full-screen overlay is covering it, so the
  // one-per-day toast is never silently burned on a screen the visitor never saw. Re-validates the
  // day/whitelist/cross-tab state at the moment of reveal, not just at schedule time.
  function attemptReveal(){
    if (revealed) return;
    if (document.visibilityState === 'hidden' || blockingOverlayOpen()){
      clearTimeout(retryTimer);
      retryTimer = setTimeout(attemptReveal, 600);
      return;
    }
    const state = getTodayState();
    if (state.shown) { revealed = true; return; }   // already shown today — this tab, another tab, or a previous visit

    revealed = true;
    nameEl.textContent = state.item.n;
    state.shown = true;
    writeState(state);
    paintIn();
  }

  function scheduleToday(){
    const state = getTodayState();
    if (state.shown) return;    // nothing to schedule — already shown today
    const delay = 7000 + Math.floor(Math.random() * 3000); // appears 7–10s after load
    scheduleTimer = setTimeout(attemptReveal, delay);
  }

  scheduleToday();

  // Re-validate on return to the tab: covers (a) a timer that fired while hidden/behind an overlay and
  // is waiting to retry, and (b) a tab left open overnight, where the date has since rolled over.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible' || revealed) return;
    const state = getTodayState();
    if (state.shown) return;
    if (!scheduleTimer && !retryTimer) scheduleToday();
  });

  // If another tab reveals (and marks) today's special first, cancel this tab's pending attempt.
  window.addEventListener('storage', (e) => {
    if (e.key !== STORAGE_KEY || !e.newValue || revealed) return;
    try {
      const latest = JSON.parse(e.newValue);
      if (latest && latest.shown && latest.date === localDateKey()){
        clearTimeout(scheduleTimer);
        clearTimeout(retryTimer);
        revealed = true;
      }
    } catch(err){ /* ignore malformed cross-tab payload */ }
  });
} catch (err) {
  // Never let this feature take the rest of the page down with it.
  if (window.console && console.error) console.error('Today\u2019s Special toast failed to initialize:', err);
}
})();

// ---------- PWA: service worker, offline state, subtle install link ----------
(function pwa(){
  const root = document.documentElement;

  // Offline indicator (used to swap the live map for a helpful note)
  function syncOnline(){ root.classList.toggle('is-offline', !navigator.onLine); }
  window.addEventListener('online', syncOnline);
  window.addEventListener('offline', syncOnline);
  syncOnline();

  // Service worker (needs http/https; skipped for file:// previews). Add ?nosw to the URL to unregister + clear caches while developing.
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)){
    const params = new URLSearchParams(location.search);
    if (params.has('nosw')){
      const wipe = () => navigator.serviceWorker.getRegistrations()
        .then(rs => Promise.all(rs.map(r => r.unregister())))
        .then(() => caches.keys())
        .then(keys => Promise.all(keys.map(k => caches.delete(k))))
        .catch(() => {});
      wipe();
      setTimeout(wipe, 1500);   // second pass: an in-flight request can recreate a cache right after the first wipe
    } else {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js', { scope: './' }).catch(() => { /* non-fatal: site works without it */ });
      });
    }
  }

  // Install: never auto-prompt. Reveal a small footer link only when the browser says install is possible.
  const installBtn = document.getElementById('installApp');
  let deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    if (installBtn) installBtn.hidden = false;
  });
  if (installBtn){
    installBtn.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      installBtn.hidden = true;
      deferredPrompt.prompt();
      try { await deferredPrompt.userChoice; } catch(e) {}
      deferredPrompt = null;
    });
  }
  window.addEventListener('appinstalled', () => { deferredPrompt = null; if (installBtn) installBtn.hidden = true; });
})();
