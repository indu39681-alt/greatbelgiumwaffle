/* Great Belgium Waffle — service worker
 *
 * Cache strategy
 *  - Precache: the app shell (HTML, CSS, JS — the JS contains the full menu data), manifest, logo/images, icons.
 *  - HTML / CSS / JS / manifest: network-first (short timeout) so a new deploy is picked up immediately,
 *    falling back to the cached copy when offline or slow. Fresh copies are written back to the cache.
 *  - Images & icons: cache-first (they change rarely; bump VERSION when they do).
 *  - Google Fonts: stale-while-revalidate in a separate cache that survives version bumps.
 *  - Everything else cross-origin (Google Maps embed, Instagram) is NOT intercepted.
 *
 * To ship an update: change VERSION below. Old caches are deleted on activate.
 */
const VERSION = 'v15-2026-11-19';
const STATIC_CACHE = 'gbw-static-' + VERSION;
const FONT_CACHE = 'gbw-fonts-v1';
const NETWORK_TIMEOUT_MS = 1500;   // fall back to the cached shell quickly on slow networks

const PRECACHE = [
  './',
  'index.html',
  'styles.css',
  'script.js',
  'manifest.webmanifest',
  'assets/logo-120.webp',
  'assets/logo.png',
  'assets/hero-480.webp',
  'assets/hero-900.webp',
  'assets/story-640.webp',
  'assets/story-1000.webp',
  'assets/favicon.ico',
  'assets/favicon-16.png',
  'assets/favicon-32.png',
  'assets/icons/icon-192.png',
  'assets/icons/icon-512.png',
  'assets/icons/icon-maskable-192.png',
  'assets/icons/icon-maskable-512.png',
  'assets/icons/apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k.startsWith('gbw-static-') && k !== STATIC_CACHE).map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

function isFontRequest(url) {
  return url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';
}

function networkFirst(request) {
  return new Promise((resolve) => {
    let settled = false;
    const fallback = () => caches.match(request, { ignoreSearch: true })
      .then((hit) => hit || (request.mode === 'navigate' ? caches.match('index.html') : undefined));

    const timer = setTimeout(() => {
      fallback().then((hit) => { if (hit && !settled) { settled = true; resolve(hit); } });
    }, NETWORK_TIMEOUT_MS);

    fetch(request)
      .then((response) => {
        clearTimeout(timer);
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(STATIC_CACHE).then((c) => c.put(request, copy));
        }
        if (!settled) { settled = true; resolve(response); }
      })
      .catch(() => {
        clearTimeout(timer);
        fallback().then((hit) => {
          if (settled) return;
          settled = true;
          resolve(hit || new Response('Offline', { status: 503, statusText: 'Offline', headers: { 'Content-Type': 'text/plain' } }));
        });
      });
  });
}

function cacheFirst(request) {
  return caches.match(request).then((hit) => {
    if (hit) return hit;
    return fetch(request).then((response) => {
      if (response && response.ok) {
        const copy = response.clone();
        caches.open(STATIC_CACHE).then((c) => c.put(request, copy));
      }
      return response;
    });
  });
}

function staleWhileRevalidate(request) {
  return caches.open(FONT_CACHE).then((cache) =>
    cache.match(request).then((hit) => {
      const refresh = fetch(request)
        .then((response) => {
          if (response && (response.ok || response.type === 'opaque')) cache.put(request, response.clone());
          return response;
        })
        .catch(() => hit || Response.error());
      return hit || refresh;
    })
  );
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  if (isFontRequest(url)) {
    event.respondWith(staleWhileRevalidate(request));
    return;
  }
  if (url.origin !== self.location.origin) return;   // maps, instagram, etc. — leave to the browser

  const path = url.pathname;
  const isShell = request.mode === 'navigate' || /\.(?:html|css|js|webmanifest)$/.test(path) || path.endsWith('/');
  if (isShell) {
    event.respondWith(networkFirst(request));
  } else {
    event.respondWith(cacheFirst(request).catch(() => caches.match(request)));
  }
});
