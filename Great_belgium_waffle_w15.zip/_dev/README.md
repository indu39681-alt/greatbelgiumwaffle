# Great Belgium Waffle — maintenance notes

`_dev/` is NOT needed on the live server. Upload everything else.

## 1. Set the real domain (do this before going live)
All absolute URLs (canonical, Open Graph, Twitter, JSON-LD, sitemap, robots) currently use the
placeholder `https://greatbelgiumwaffle.example`. Replace it in one step:

    python3 _dev/set-domain.py https://www.your-real-domain.com

The site must be served over HTTPS for the service worker / install prompt to work.

## 2. After changing the menu, FAQ, or reviews
The JSON-LD structured data and the no-JavaScript menu list are generated from the live markup.
Re-run:

    node _dev/build-structured-data.js

Menu data lives in the `MENU` array at the top of `script.js` (single source of truth).

## 3. Shipping an update to returning visitors (PWA)
Edit `VERSION` at the top of `sw.js` (e.g. `v6-2026-10-15`). Old caches are removed automatically.
HTML/CSS/JS are served network-first, so changes appear on the next online visit.

## 4. Development
Open the site with `?nosw` (e.g. `http://localhost:8000/?nosw`) to unregister the service worker and clear its caches.

## Note on review markup
The three reviews are marked up as `Review` items on the business. Google treats reviews a business
shows about itself as "self-serving" and does not use them for star rich results — the markup is
accurate machine-readable content, not a way to obtain stars.

## Performance notes (v11)
- Looping animations pause automatically while their section is off-screen (`.is-paused`, set by an IntersectionObserver).
- Parallax runs only on hover-capable desktops and is skipped for reduced motion.
- Images are WebP with `srcset`; the original JPG/PNG files stay in `assets/` for Open Graph / structured data only.
- The service worker serves the cached page after 1.5 s if the network is slow. Bump `VERSION` in `sw.js` for each release.
