#!/usr/bin/env python3
"""Replace the placeholder domain everywhere, then regenerate structured data.

Usage (from the site root):
    python3 _dev/set-domain.py https://www.your-real-domain.com
"""
import sys, re, subprocess, pathlib

if len(sys.argv) != 2 or not re.match(r'^https?://[^/\s]+$', sys.argv[1].rstrip('/')):
    sys.exit('Usage: python3 _dev/set-domain.py https://www.your-domain.com')

new = sys.argv[1].rstrip('/')
root = pathlib.Path(__file__).resolve().parent.parent
canon = re.search(r'<link rel="canonical" href="([^"]+)"', (root / 'index.html').read_text(encoding='utf-8')).group(1).rstrip('/')

for name in ('index.html', 'sitemap.xml', 'robots.txt'):
    p = root / name
    p.write_text(p.read_text(encoding='utf-8').replace(canon, new), encoding='utf-8')
subprocess.check_call(['node', str(root / '_dev' / 'build-structured-data.js')])
print(f'Domain switched: {canon} -> {new}')
