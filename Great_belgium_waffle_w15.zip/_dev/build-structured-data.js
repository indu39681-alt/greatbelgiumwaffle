#!/usr/bin/env node
/*
 * Generates (from the site's own source of truth):
 *   1. JSON-LD structured data  -> <script id="structured-data"> in index.html
 *   2. a <noscript> menu list   -> between NOSCRIPT-MENU markers in index.html
 *
 * Menu  : read from the MENU array in script.js
 * FAQ   : read from the visible .faq-item markup in index.html
 * Reviews: read from the visible .testi-card markup in index.html
 * Base URL: read from <link rel="canonical"> in index.html
 *
 * Usage (from the site root):  node _dev/build-structured-data.js
 * Re-run whenever the menu, FAQ, reviews or domain change.
 */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const htmlPath = path.join(root, 'index.html');
let html = fs.readFileSync(htmlPath, 'utf8');
const js = fs.readFileSync(path.join(root, 'script.js'), 'utf8');

const decode = (s) => s
  .replace(/&amp;/g, '&').replace(/&rsquo;/g, '\u2019').replace(/&lsquo;/g, '\u2018')
  .replace(/&ndash;/g, '\u2013').replace(/&mdash;/g, '\u2014')
  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// ---- base URL ----
const canonical = html.match(/<link rel="canonical" href="([^"]+)"/);
if (!canonical) throw new Error('canonical link not found');
const BASE = canonical[1].replace(/\/+$/, '');
const URL_HOME = BASE + '/';
const ID = { site: URL_HOME + '#website', page: URL_HOME + '#webpage', biz: URL_HOME + '#business', menu: URL_HOME + '#menu', faq: URL_HOME + '#faq' };

// ---- menu ----
const menuSrc = js.match(/const MENU = \[[\s\S]*?\n\];/);
if (!menuSrc) throw new Error('MENU array not found in script.js');
const MENU = new Function(menuSrc[0].replace('const MENU', 'var MENU') + '; return MENU;')();

const offer = (price, name) => {
  const o = { '@type': 'Offer', price: String(price), priceCurrency: 'INR' };
  if (name) o.name = name;
  return o;
};
const menuSections = MENU.map((cat) => ({
  '@type': 'MenuSection',
  name: cat.label,
  hasMenuItem: cat.items.map((it) => ({
    '@type': 'MenuItem',
    name: it.n,
    offers: it.prices
      ? Object.entries(it.prices).map(([size, price]) => offer(price, size))
      : offer(it.p ?? it.priceText)
  }))
}));

// ---- FAQ (visible markup) ----
// The answer can contain nested markup (e.g. the opening-hours table), so a non-greedy regex up to the
// first "</div>" would truncate it. Instead: find each "faq-a-inner" div, then walk forward counting
// div open/close tags to find ITS true matching close, and convert the inner HTML to plain text
// (table rows -> "Day — time" lines) rather than just stripping tags.
function htmlToPlainText(fragment) {
  let s = fragment
    .replace(/<div class="hours-row">\s*<span class="hours-day">([\s\S]*?)<\/span>\s*<span class="hours-time">([\s\S]*?)<\/span>\s*<\/div>/g,
      (_, day, time) => `${decode(day)} \u2014 ${decode(time)}.\n`)
    .replace(/<\/p>|<\/li>|<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');
  return decode(s).split('\n').map((l) => l.trim()).filter(Boolean).join(' ').trim();
}

function extractBalancedDiv(src, openIndex) {
  // src[openIndex] is the start of an opening "<div...>" tag; returns the inner HTML up to its matching close.
  const tagEnd = src.indexOf('>', openIndex) + 1;
  const divRe = /<div\b[^>]*>|<\/div>/gi;
  divRe.lastIndex = tagEnd;
  let depth = 1, match;
  while ((match = divRe.exec(src))) {
    if (match[0].toLowerCase() === '</div>') { depth--; if (depth === 0) return src.slice(tagEnd, match.index); }
    else depth++;
  }
  throw new Error('unbalanced <div> while parsing FAQ answer');
}

const faq = [];
const faqItemRe = /<div class="faq-item">[\s\S]*?<button class="faq-q"[^>]*>([\s\S]*?)<span class="chev"/g;
let m;
while ((m = faqItemRe.exec(html))) {
  const q = decode(m[1]);
  const innerTag = html.indexOf('<div class="faq-a-inner">', m.index);
  const answerHtml = extractBalancedDiv(html, innerTag);
  faq.push({ q, a: htmlToPlainText(answerHtml) });
}
if (!faq.length) throw new Error('no FAQ items found');

// ---- reviews (visible markup) ----
const reviews = [];
const revRe = /<blockquote class="testi-text"><p>"([\s\S]*?)"<\/p><\/blockquote>\s*<footer class="testi-who"><cite class="testi-name">([\s\S]*?)<\/cite>/g;
while ((m = revRe.exec(html))) reviews.push({ text: m[1].trim(), name: decode(m[2]) });
if (!reviews.length) throw new Error('no reviews found');

const graph = [
  {
    '@type': 'WebSite',
    '@id': ID.site,
    url: URL_HOME,
    name: 'Great Belgium Waffle',
    inLanguage: 'en-IN',
    publisher: { '@id': ID.biz }
  },
  {
    '@type': 'WebPage',
    '@id': ID.page,
    url: URL_HOME,
    name: 'Great Belgium Waffle | Belgian Waffles, Shakes & Mocktails in Chatrapur',
    description: 'Great Belgium Waffle in Chatrapur, Odisha — explore Belgian waffles, loaded waffles, waffle cakes, thick shakes, mocktails, desserts and delicious bites.',
    inLanguage: 'en-IN',
    isPartOf: { '@id': ID.site },
    about: { '@id': ID.biz },
    primaryImageOfPage: { '@type': 'ImageObject', url: BASE + '/assets/og-image.png', width: 1200, height: 630 }
  },
  {
    '@type': 'CafeOrCoffeeShop',
    '@id': ID.biz,
    name: 'Great Belgium Waffle',
    url: URL_HOME,
    description: 'A local café in Chatrapur serving Belgian waffles, desserts, thick shakes, mocktails and bites.',
    image: [BASE + '/assets/og-image.png', BASE + '/assets/hero.jpg', BASE + '/assets/story.jpg'],
    logo: { '@type': 'ImageObject', url: BASE + '/assets/logo.png', width: 400, height: 400 },
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Bus Stand, Upper, in front of Sai Baba Electronics',
      addressLocality: 'Chatrapur',
      addressRegion: 'Odisha',
      postalCode: '761020',
      addressCountry: 'IN'
    },
    hasMap: 'https://maps.app.goo.gl/ARPTuKHhPt5yApsL7',
    sameAs: ['https://www.instagram.com/greatbelgiumwafflectp/'],
    mainEntityOfPage: { '@id': ID.page },
    hasMenu: { '@id': ID.menu },
    review: reviews.map((r) => ({
      '@type': 'Review',
      author: { '@type': 'Person', name: r.name },
      reviewBody: r.text,
      reviewRating: { '@type': 'Rating', ratingValue: '5', bestRating: '5', worstRating: '1' },
      itemReviewed: { '@id': ID.biz }
    }))
  },
  {
    '@type': 'Menu',
    '@id': ID.menu,
    name: 'Great Belgium Waffle Menu',
    url: URL_HOME + '#menu',
    inLanguage: 'en-IN',
    hasMenuSection: menuSections
  },
  {
    '@type': 'FAQPage',
    '@id': ID.faq,
    url: URL_HOME + '#faq',
    mainEntity: faq.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a }
    }))
  }
];

const jsonld = JSON.stringify({ '@context': 'https://schema.org', '@graph': graph }, null, 2)
  .replace(/</g, '\\u003c');   // safe inside <script>

html = html.replace(
  /(<script type="application\/ld\+json" id="structured-data">)[\s\S]*?(<\/script>)/,
  `$1\n${jsonld.replace(/\$/g, '$$$$')}\n$2`
);

// ---- <noscript> menu fallback ----
const badge = { star: '⭐', fire: '🔥', crown: '👑' };
const ns = MENU.map((cat) => {
  const lis = cat.items.map((it) => {
    const price = it.prices ? Object.entries(it.prices).map(([s, p]) => `${s} ${p}`).join(' / ') : (it.p ?? it.priceText);
    return `        <li>${badge[it.badge] ? badge[it.badge] + ' ' : ''}${esc(it.n)} \u2014 ${price}</li>`;
  }).join('\n');
  return `      <h3>${esc(cat.label)}</h3>\n      <ul>\n${lis}\n      </ul>`;
}).join('\n');
const noscript = `<!-- NOSCRIPT-MENU:START -->\n    <noscript>\n    <div class="noscript-menu">\n${ns}\n    </div>\n    </noscript>\n    <!-- NOSCRIPT-MENU:END -->`;
html = html.replace(/<!-- NOSCRIPT-MENU:START -->[\s\S]*?<!-- NOSCRIPT-MENU:END -->/, noscript.replace(/\$/g, '$$$$'));

fs.writeFileSync(htmlPath, html);
const items = MENU.reduce((n, c) => n + c.items.length, 0);
console.log(`structured data written: ${MENU.length} sections, ${items} menu items, ${faq.length} FAQs, ${reviews.length} reviews (base ${BASE})`);
